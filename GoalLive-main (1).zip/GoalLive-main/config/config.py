YELP_API_KEY = "idwu-jXaO-1spEHqIpUTTXd3ypT-vrtDLKLvAwwUGjpiLgOTAd1w2YMIEM1R_MjVkdv7bO5Gkr7Y7GGMvJjnxNZ409Me2KqBIy8wp-MbkkGcl38coLrLBnkWdO5IZ3Yx"

GOAL_LIVE_BASE_URL = "https://www.goal.com/en-us/fixtures/__path"