class Team:
    def __init__(self, team_name, team_image_url) -> None:
        self.team_name = team_name
        self.team_image_url = team_image_url